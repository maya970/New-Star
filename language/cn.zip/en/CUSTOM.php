<?php
// Translated into English by Yaro2709;
// All rights reserved from 2020;
// Company 1367.

$LNG['all']                                          = '全部';
// Messages
$LNG['mg_type'][200]                                 = '记录';
$LNG['mg_text']                                      = '文本';
$LNG['mg_arh_mess']                                  = '存档所有选定的记录';
$LNG['mg_arh']                                       = '已存档的文件';
$LNG['mg_del']                                       = '删除';
$LNG['mg_fre']                                       = '邀请您的朋友';
// Settings
$LNG['op_user']                                      = '用户';
$LNG['op_vacation']                                  = '假日模式';
$LNG['op_foto']                                      = 'Avatar (add url)';
$LNG['op_background']                                = 'Background (add url)';
// Records
$LNG['rec_you']                                      = '和你一起';
$LNG['rec_record']                                   = '记录';
$LNG['rec_user_top']                                 = '记录设定';
//Resources
$LNG['res_disable']                                  = '禁止在所有行星上进行采矿';
$LNG['res_activate']                                 = '允许在所有行星上进行采矿';
$LNG['res_cl_dactivate']                             = '在所有行星上的采矿工作都已被禁用';
$LNG['res_cl_activate']                              = '所有行星都可以进行采矿';
// Purchase - sale
$LNG['bd_limit']                                     = '你不能买到这么多的东西!';
$LNG['bd_notres']                                    = '资源不足!';
$LNG['bd_buy']                                       = '买';
$LNG['bd_support']                                   = '支持';
$LNG['bd_time_day']                                  = '天数:';
$LNG['bd_time_weeks']                                = '周数:';
$LNG['bd_lvl_up']                                    = 'Lv.:';
$LNG['bd_quantity_up']                               = '合计:';
$LNG['bd_active']                                    = '活动:';
$LNG['bd_recharge']                                  = '休整:';
$LNG['bd_restart_no']                                = 'Wait...';
$LNG['bd_total']                                     = '合计:';
$LNG['bd_the_initial_cost']                          = '初始成本:';
$LNG['bd_the_cost']                                  = '花费:';
$LNG['bd_buy_yes']                                   = '购买!';
$LNG['bd_buy_no_tech']                               = '你没有打开的单位!';
$LNG['bd_needed_tech']                               = '若要构建它，您需要:';
//Support
$LNG['ti_category_error']                            = '错误';
$LNG['ti_category_bug']                              = 'Bug';
$LNG['ti_category_language']                         = '语言错误';
$LNG['ti_mess']                                      = '信息';
// Suppot
$LNG['nt_text']                                      = '文本';
$LNG['nt_title']                                     = '主题';
// Umperium
$LNG['lv_sum']                                       = '合计';
$LNG['lv_resources_h']                               = '每小时提供的资源';
$LNG['lv_max']                                       = '全部';
$LNG['lv_max_planet']                                = '行星系';
$LNG['lv_max_moon']                                  = '月亮';
$LNG['lv_max_colon']                                 = '行星的状态 (殖民地):';
$LNG['lv_go_planet']                                 = '继续';
//Orbit
$LNG['fl_fleet_grops']                               = '舰队';
$LNG['fl_new_grops']                                 = '添加舰队组插槽';
$LNG['fl_new_name_grops']                            = '指定已保存的组的名称';
$LNG['fl_fleet_points']                              = '选定的舰队作战点';
$LNG['fl_grop_1']                                    = '作战舰队';
$LNG['fl_grop_2']                                    = '交通运输系统';
$LNG['fl_grop_3']                                    = '回收设备';
$LNG['fl_grop_4']                                    = '特殊的';
//The buildings
$LNG['bd_free_field']                                = '剩余区划:';
$LNG['bd_em_field']                                  = '已用区划:';
$LNG['bd_of_field']                                  = '全部区划:';
$LNG['short_day']                                    = 'd';
$LNG['short_hour']                                   = 'h';
$LNG['short_minute']                                 = 'm';
$LNG['short_second']                                 = 's';
//Accelerator
$LNG['cost']                                         = '产品价格';
//Overview
$LNG['ov_ticket']                                    = '在技术方面的支持部分';
$LNG['ov_ticket_tooltip']                            = '我会回答你的问题的';
$LNG['ov_online_users']                              = '在线玩家:';
$LNG['ov_create_moon']                               = '创造月亮';
$LNG['ov_panel_root']                                = '控制面板';
//Navigation
$LNG['lm_market']                                    = '市场';
$LNG['lm_blueprints']                                = '产品蓝图';
$LNG['lm_race']                                      = '种族';
$LNG['lm_premium']                                   = '溢价';
$LNG['lm_bonus']					                 = '每日签到'; 
$LNG['lm_infobonus']					             = '更多效果'; 
$LNG['lm_createmoon']					             = '创造月亮'; 
$LNG['lm_ars']					                     = '工业标准';
$LNG['lm_container']					             = '军火库';
$LNG['lm_artifact']                                  = '史前古器物';
$LNG['lm_development']                               = '创新性的发展';
$LNG['lm_achievements']					             = '成就';
$LNG['lm_formgovernment']                            = '政府的形式';
$LNG['lm_ethics']                                    = '伦理学规范';
$LNG['lm_party']					                 = '党派';
$LNG['lm_ideologies']					             = '意识形态';
$LNG['lm_band']                                      = '雇佣兵人员';
$LNG['lm_bon']                                       = '古旧的集装箱';
$LNG['lm_fair']                                      = '公平';
$LNG['lm_auction']                                   = '拍卖活动';
$LNG['lm_buybuild']                                  = '购买建筑物';
$LNG['lm_buytech']                                   = '采购情况研究';
$LNG['lm_buyfleet']                                  = '购买舰队';
$LNG['lm_buydefense']                                = '购买防御';
$LNG['lm_planet']                                    = '天文馆';
$LNG['lm_reduceresources']                           = '从行星上删除资源';
$LNG['lm_reducefleet']                               = '从行星上移出宇宙舰队';
$LNG['lm_delivery']                                  = '从行星上分配资源';
$LNG['lm_finddebris']                                = '查找碎片的信息';
$LNG['lm_store']                                     = '商场';
$LNG['lm_minerals']                                  = '矿物类';
$LNG['lm_details']                                   = '细节';
$LNG['PPS']                                          = '每小时的生产量';
$LNG['PPD']                                          = '每天的生产量';
$LNG['PPW']                                          = '每周的生产量';
$LNG['RE']                                           = '提供:';
//Statistics
$LNG['st_next']                                      = '下一次更新';
// Mapket
$LNG['market_indicated']                             = '未指定的价格.';
$LNG['market_exposed']                               = '已提交的报价!';
$LNG['market_not_enough_money']                      = '您没有足够的资源!';
$LNG['market_buy']                                   = '市场交易取得成功!';
$LNG['market_take_off']                              = '该项目已退出销售!';
$LNG['market_lot_active']                            = '在市场上提供的服务';
$LNG['market_go_lot']                                = '提出报价';
$LNG['market_you_lot']                               = '您提供的报价';
$LNG['market_not_lot']                               = '无报价!';
$LNG['market_not_res']                               = '你在市场上没有什么可提供的!';
$LNG['market_not_lot_active']                        = '您没有任何主动的报价!';
$LNG['market_take']                                  = '删除相关报价';
$LNG['market_proceed']                               = '继续';
$LNG['market_price']                                 = '价格:';
$LNG['market_all']                                   = '全部';
$LNG['market_lot']                                   = '提供';
// Alliances
$LNG['all_of']                                       = '的性质是';
$LNG['all_member']                                   = '成员';
$LNG['all_status']                                   = '联盟的概述';
$LNG['all_info']                                     = '相关信息';
$LNG['all_appl']                                     = '配置要求';
$LNG['all_create']                                   = '创建等级';
$LNG['al_development']                               = 'Development';
$LNG['al_storage']                                   = 'Storage';
$LNG['al_issue']                                     = 'Issue';
$LNG['al_issue_ally_storage']                        = 'Issue from Alliance Bank';
$LNG['al_vlyat']                                     = 'Get it';
$LNG['al_vlyat_ally_storage']                        = 'Take from Alliance Bank';
$LNG['al_put']                                       = 'Contribute';
$LNG['al_summ_max']                                  = 'Maximum';
$LNG['al_summ_all']                                  = 'Amount';
$LNG['al_in_storage']                                = 'In Stock';
$LNG['al_ally_planets']                              = 'Planets';
$LNG['al_storage_msg_enter']                         = 'Please enter resources!';
$LNG['al_storage_msg_much']                          = 'Too Much!';
$LNG['al_storage_msg_not']                           = 'Not enough!';
$LNG['al_storage_msg_success']                       = 'Deposit completed.';
$LNG['al_storage_msg_received']                      = 'Resources received.';
$LNG['al_storage_msg_issued']                        = 'Resources issued.';
$LNG['al_storage_msg_coordinates']                   = 'No resource delivery coordinates selected.';
// Races
$LNG['race_one']                                     = '选择种族:';
$LNG['race_yes']                                     = '已选择种族.';
//Conveyor
$LNG['sec_conv']                                     = '每秒运行一次';
//Info bonus
$LNG['inb_percent']                                  = '占百分比';
$LNG['inb_units']                                    = '单位';
$LNG['inb_name']                                     = '名字';
//Create moon
$LNG['crm_value']                                    = '要创造月球，需要:';
$LNG['crm_war']                                      = '月球的直径是随机的!';
$LNG['crm_create']                                   = '月亮被成功地创造出来了!';
$LNG['crm_moon_is']                                  = '这个星球上已经有了月亮了！';
$LNG['crm_not_res']                                  = '您没有足够的资源!';
//Container
$LNG['cont_open_go']                                 = '打开';
$LNG['cont_open_24']					             = '在24小时内开放.';
$LNG['cont_msg_limit']                               = '您一次不能打开那么多的容器.';
$LNG['cont_not_cont_user']                           = '容器数量不足!';
$LNG['cont_open']                                    = '您已打开了:';
//Information
$LNG['in_attack_pt']                                 = '标准的攻击';
$LNG['in_attack_laser']                              = '激光攻击';
$LNG['in_attack_ionic']                              = '离子攻击';
$LNG['in_attack_buster']                             = '等离子攻击';
$LNG['in_attack_graviton']                           = '重力攻击';
$LNG['in_shield_none']                               = '没有护盾';
$LNG['in_shield_light']                              = '轻型护盾';
$LNG['in_shield_medium']                             = '中型护盾';
$LNG['in_shield_heavy']                              = '重型护盾';
$LNG['in_armor_light']                               = '轻型装甲';
$LNG['in_armor_medium']                              = '中型装甲';
$LNG['in_armor_heavy']                               = '重型装甲';
$LNG['in_number']                                    = '数量';
$LNG['in_recovery']                                  = '在战斗结束后，人们正在恢复防御能力.';
//System
$LNG['sys_expe_found_ars_1']                         = '我们找到了战场，我们可以进行提高';
$LNG['sys_expe_found_ars_2']                         = '新指挥官允许与新种族接触，尽管这违反了宪章。结果她很友好，我们得以建立贸易关系。成功完成交换后，探险队得到了升级 ';
$LNG['sys_expe_found_ars_3']                         = '新团队决定使用新的搜索模块。因此，探险队能够很快找到一颗小行星。经过研究，研究小组发现了一个升级版本 ';
$LNG['sys_expe_found_ars_4']                         = '探险队发现了一个更高级种族的坏机器人。经过检查，团队能够创建一个升级。';
$LNG['sys_expe_found_ars_5']                         = '探险队本应该空手而归，但在路线的尽头，我们发现了一个巨大的被毁的小行星。研究了很长一段时间后，这个团队能够创建一个升级';
$LNG['sys_expe_found_ars_6']                         = '探险的开始已经很糟糕了。中途，大多数船员都生病了，但幸运的是，在路上我们遇到了一艘外星飞船。我们能够就交换氘达成一致，我们有很多氘，来治愈团队并升级 ';
$LNG['sys_expe_found_ars_7']                         = '探险队认为这次探险相当成功。我们拍了很多有趣的太空照片，我们认为他们会赢得比赛，而且在旅程的开始就发现了升级 ';
$LNG['sys_expe_found_container_1']                   = '这次探险并不特别成功。我们在小行星上进行了几次不成功的着陆，还试图从小行星上提取资源，但不幸的是，每次设备故障，或者最坏的情况下，数据都不正确。在回家的路上，我们遇到了一个战场。不久前它就出现了，我们能把它保存在容器里';
$LNG['sys_expe_found_container_2']                   = '聪明的指挥员给船装备了最新的装备。这帮助我们很快找到了一个几乎被摧毁的小行星。通过研究，我们找到了数据。它们被记录了近期事件的历史，以及行星装置的计划。他帮我们找到了一个装有集装箱的仓库';
$LNG['sys_expe_found_container_3']                   = '这次探险很有趣，也很成功。我们遇到了许多不同的种族，做实验，甚至设法有一个良好的休息。最后，我们飞到了一个标记很长的地方，我们过去在那里开采资源，但这次我们看到了最近战斗的战场。我们能把所有东西都保存在容器里';
$LNG['sys_expe_found_container_4']                   = '我们在空旷的地方徘徊了很长时间，因为指挥官没有成功地选择我们的路线。违反了章程，我们一致把他关进了牢房。改变探险路线，探险队发现了不同种族的船只，集装箱在哪里';
$LNG['sys_expe_found_container_5']                   = '探险队没有消耗多少体力。在旅程的一开始，我们就录下了一个信号。飞得离目标更近了，我们意识到那是一艘商船。研究小组用暗物质交换容器';
$LNG['sys_expe_found_so_1']                          = '探险队偶然发现了一颗已灭绝的恒星，并成功地从中提取了一颗 <span style = "color:#e8ce10">星尘</span>.';
$LNG['sys_expe_found_so_2']                          = '在恒星爆炸后，探险队偶然发现了被摧毁的星系，并发现了一个 <span style = "color:#e8ce10">星尘</span>.';
$LNG['sys_expe_found_so_3']                          = '探险队发现了一个破裂的黑洞反应堆并提取了一个<span style = "color: #e8ce10">星尘</span>.';
$LNG['sys_expe_found_so_4']                          = '探险队发现了古人留下的系统。在一个星球上，有一个资源仓库 <span style = "color:#e8ce10">星辰</span>被发现. ';
$LNG['sys_expe_found_so_5']                          = "探险队遇到了一个奇怪的异常情况，之后我们发现自己就在被遗弃的海盗基地附近。一个 <span style = 'color:#e8ce10'>星尘</span> 是在机库里发现的.";
$LNG['sys_expe_found_so_6']                          = '探险队遇到一艘不知名的船。在谈判中，我们用暗物质交换了一个 <span style = "color:#e8ce10">星尘</span>. ';
$LNG['sys_expe_found_so_7']                          = '探险没有成功。但是在回来的路上我们发现了一个集装箱里面有一个 <span style = "color:#e8ce10">星尘</span>. ';
//Achievements
$LNG['ach_system']					                 = '系统';
$LNG['ach_reached']					                 = '获得:';
$LNG['ach_bonus']					                 = '查看奖励';
$LNG['ach_next_upg']					        	 = '下一层的奖励:';
$LNG['ach_remaining']					        	 = '剩余的升级功能:';
$LNG['ach_go_achievements']					         = '查看成就';
//Form of government
$LNG['fg_one']                                       = '选择政府的具体形式:';
$LNG['fg_yes']                                       = '已选择了政府的形式.';
//Ethics
$LNG['et_one']                                       = '道德选择:';
$LNG['et_yes']                                       = '所选择的伦理学规范.';
//The consignment
$LNG['party_stop_time']                              = '已选择了一个政党!';
//Planetarium
$LNG['pla_notenogu']                                 = '没有足够的暗物质';
$LNG['pla_tel_fleet']                                = '战斗中的舰队';
$LNG['pla_no_planet']                                = '你必须从这个星球传送';
$LNG['pla_tel_busy']                                 = '坐标占线';
$LNG['pla_reactor']                                  = '反应堆是热的!';
$LNG['pla_tel_ok']                                   = '行星传送';
$LNG['pla_added']                                    = '已添加的内容!';
$LNG['pla_error']                                    = '错误!';
$LNG['pla_increase_in_fields']                       = '增加了地球上的磁场';
$LNG['pla_increase_in_diameter']                     = "增加了行星的直径";
$LNG['pla_incre_ok']                                 = '增加';
$LNG['pla_tele_pal']                                 = '传送的行星';
$LNG['pla_tele_gal']                                 = ' 宇宙';
$LNG['pla_tele_sys']                                 = ' 系统';
$LNG['pla_tele_pla']                                 = ' 星球';
$LNG['pla_tel_next']                                 = '在非系统上，将会是可用的';
$LNG['pla_tele_sub']                                 = '传送';
$LNG['pla_gen']                                      = '生成的';
$LNG['pla_new_name']                                 = '给星球的取新名字';
$LNG['pla_del']                                      = '移除星球';
$LNG['pla_pass']                                     = '密码';
$LNG['pla_send']                                     = '确定';
// Resource distribution
$LNG['rd_select_palet_res']                          = '选择要向其发送资源的行星';
$LNG['rd_not_nid_fleet']                             = '没有合适的舰队';
$LNG['rd_not_deiterium']                             = '
Not enough deuterium
氘不足';
$LNG['rd_not_conpustion']                            = '有效载荷不足';
$LNG['rd_select_palet_fleet']                        = '选择要派出舰队的行星';
$LNG['rd_compustion']                                = '重氢的消耗';
$LNG['rd_sell']                                      = '花费';
$LNG['rd_planet_no']                                 = '你没有UAZ行星.';
$LNG['rd_fleet_go']                                  = '舰队已经被派去了.';
$LNG['rd_fleet_po']                                  = '您处于假期模式.';
$LNG['rd_fleet_slot']                                = '所有机队的机位都很忙.';
$LNG['rd_erorr']                                     = '错误!';
$LNG['rd_select_all']                                = '选择全部';
$LNG['rd_reset_all']                                 = '重置选择';
$LNG['rd_planet_no_fleet']                           = '没有合适的行星';
$LNG['rd_fleet_point']                               = '机队总数:';
//Wreck Finder
$LNG['debris_title']					             = '碎片探测器';
$LNG['debris_show']					                 = '显示碎片';
$LNG['debris_range']					             = '范围';
$LNG['debris_action_1']					             = '宇宙';
$LNG['debris_action_2']					             = '系统';
$LNG['debris_action_3']					             = '星球';
$LNG['debris_action_4']					             = '
Debris Metal
金属碎片';
$LNG['debris_action_5']					             = '
Debris Crystal
碎片晶体';
$LNG['debris_action_6']					             = '
Collect
收集';
$LNG['debris_action_7']					             = '你的射程里没有碎片';
//Overview
$LNG['ov_bottom_panel_text']                         = '邀请新玩家';
$LNG['ov_bottom_panel_head']                         = '更多';
//Galaxy
$LNG['gl_sp']                                        = '
Intelligence
智力';
//Player card
$LNG['op_user_info']                                 = '关于玩家';
$LNG['op_damage_coef']                               = '损伤系数';
// Expeditions
$LNG['fl_enemy'][1]                                  = '海盗';
$LNG['fl_enemy'][2]                                  = '外星人';
$LNG['fl_enemy'][3]                                  = '古人';
$LNG['fl_enemy_text'][1]                             = "
<b>海盗：</b><br>

找到升级的机会：10%<br>

舰队的数量是玩家发动舰队的60-70%。<br>你知道吗

盗版技术占玩家技术的60-70%。<br>你知道吗

找到暗物质的基本几率为30%<br>

最低车队积分2.500<br>

车队积分的最大数量不受限制<br>

舰队碎片收集率：1%<br> ";
$LNG['fl_enemy_text'][2]                             = "<b>外星人：</b><br>

找到升级的机会：10%<br>

机队的数量是玩家发动机队的70-80%。<br>你知道吗

外星人科技占玩家科技的70-80%。<br>你知道吗

找到暗物质的基本几率为30%<br>

最少车队积分15000<br>

车队积分的最大数量不受限制<br>

舰队碎片收集率：2%<br>";
$LNG['fl_enemy_text'][3]                             = "<b>古人：</b><br>

找到升级的机会：10%<br>

舰队的数量是玩家发动舰队的80-90%。<br>你知道吗

古代科技占玩家科技的80-90%。<br>你知道吗

找到暗物质的基本几率为30%<br>

最少车队积分25000<br>

车队积分的最大数量不受限制<br>

舰队碎片收集率：3%<br> "; 
$LNG['batl_log_mesage']				                 = '<div class="raportMessage">
	<table>
		<tr>
			<td colspan="2"><a href="CombatReport.php?raport=%s" onclick="starttraining20()" target="_blank"><span %s>%s %s (%s)</span></a></td>
		</tr>
		<tr>
			<td>%s</td><td><span %s>%s: %s</span>&nbsp;<span %s>%s: %s</span></td>
		</tr>
		<tr>
			<td>%s</td><td><span>%s:&nbsp;<span style="color:#a47d7a;">%s</span>&nbsp;</span><span>%s:&nbsp;<span style="color:#5ca6aa;">%s</span>&nbsp;</span><span>%s:&nbsp;<span style="color:#339966;">%s</span></span></td>
		</tr>
		<tr>
			<td>%s</td><td><span>%s:&nbsp;<span style="color:#a47d7a;">%s</font>&nbsp;</span><span>%s:&nbsp;<span style="color:#5ca6aa;">%s</span></span></td>
		</tr>
	</table>
</div>' ;        
$LNG['host_mission_mesag']                           = '星云扇区';
$LNG['fl_enemy_msg']['main']                         = '探险队偶然发现了一支敌军部队 %s 在星云区.';
$LNG['fl_enemy_msg']['tm']                           = '找到一个含有 %s 暗物质的容器.';
$LNG['fl_enemy_msg']['up']                           = '可以为 %s 创建 %s 个数为 %s 的升级';