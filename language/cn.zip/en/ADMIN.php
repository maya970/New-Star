<?php
// Translated into English by Yaro2709;
// All rights reserved from 2020;
// Company 1367.

//NAVIGATION:
//{IDs_0001} Posts
//{IDs_0002} ID
//{IDs_0003} Time
//{IDs_0004} Buttons
//{IDs_0005} Status
//{IDs_0006} Class
//{IDs_0007} Login
//{IDs_0008} Menus and Titles
//{IDs_0009} Home
//{IDs_0010} Information
//{IDs_0010} Parameters
//{IDs_0011} Parameters of the universe
//{IDs_0012} Accounts
//{IDs_0013} Security code
//{IDs_0014} Mail
//{IDs_0015} Messages
//{IDs_0016} Visit statistics
//{IDs_0017} Chat
//{IDs_0018} Teamspeak
//{IDs_0019} Main parameters
//{IDs_0020} Queue
//{IDs_0021} Referral system
//{IDs_0022} Colonization
//{IDs_0023} New planets
//{IDs_0024} Miscellaneous
//{IDs_0025} Fleet Buyer
//{IDs_0026} News
//{IDs_0027} Statistics
//{IDs_0028} Facebook
//{IDs_0029} Contacts
//{IDs_0030} Modules
//{IDs_0031} Task Scheduler
//{IDs_0032} Database backup
//{IDs_0033} Universes
//{IDs_0034} Rights
//{IDs_0035} Zeroing
//{IDs_0036} Create
//{IDs_0037} Creating a player
//{IDs_0038} Creating a planet
//{IDs_0039} Creating the moon
//{IDs_0040} Account Editor
//{IDs_0041} Planet Editor
//{IDs_0042} Alliance Editor
//{IDs_0043} Personal data editor
//{IDs_0044} Other editor
//{IDs_0045} Lock Panel
//{IDs_0046} Gifts
//{IDs_0047} Tech. support
//{IDs_0048} Activation page
//{IDs_0049} Fleets in flight
//{IDs_0050} News
//{IDs_0051} List of messages
//{IDs_0052} Advanced Search
//{IDs_0053} Advanced Search - Players
//{IDs_0054} Advanced Search - Planets
//{IDs_0055} Advanced search - blocked
//{IDs_0056} Advanced Search - Alliance
//{IDs_0057} Fast editor
//{IDs_0058} Multi-Accounts
//{IDs_0059} Global message
//{IDs_0060} Logs
//{IDs_0061} MD5 encryption
//{IDs_0062} Cache
//{IDs_0063} Updating statistics
//{IDs_0064} Logout

//{IDs_0001} Posts
$LNG['rank_0']                                       = '玩家';
$LNG['rank_1']                                       = '调解人';
$LNG['rank_2']                                       = '经营者';
$LNG['rank_3']                                       = '管理';
//{IDs_0002} ID
$LNG['input_id']                                     = 'ID';
$LNG['input_id_user']                                = '玩家 ID';
$LNG['input_id_planet']                              = '星球 ID';
$LNG['input_id_moon']                                = '月亮 ID';
$LNG['input_id_p_m']                                 = '星球ID 或 月球ID';
$LNG['input_id_ally']                                = '联盟 ID';
//{IDs_0003} Time
$LNG['time_days']                                    = '日';
$LNG['time_hours']                                   = '小时';
$LNG['time_minutes']                                 = '分钟';
$LNG['time_seconds']                                 = '秒';
//{IDs_0004} Buttons
$LNG['button_submit']                                = '保存';
$LNG['button_proceed']                               = '继续';
$LNG['button_add']                                   = '加';
$LNG['button_delete']                                = '删除';
$LNG['button_filter']                                = '滤过';
$LNG['button_deselect']                              = '取消';
$LNG['button_reset']                                 = '充值';
$LNG['button_des_se']                                = '全部标记';
$LNG['button_active']                                = '可用';
$LNG['button_deactive']                              = '不可用';
$LNG['button_view']                                  = '展示';
//{IDs_0005} Status
$LNG['status_yes']                                   = 'Yes';
$LNG['status_no']                                    = 'No';
$LNG['status_active']                                = '可用';
$LNG['status_deactive']                              = '不可用';
$LNG['status_parameter']                             = '参数';
$LNG['status_value']                                 = '价值';
$LNG['status_option']                                = '挑选...';
//{IDs_0006} Class
$LNG['class_name']                                   = '名字';
$LNG['class_lvl']                                    = '等级';
//{IDs_0007} Login
$LNG['ln_username']                                  = '登录';
$LNG['ln_password']                                  = '密码';
//{IDs_0008} Menus and Titles
$LNG['lm_login']                                     = '管理面板 - 登录';
$LNG['lm_overview']                                  = '首页';
$LNG['lm_information']                               = '系统信息';
$LNG['lm_configuni']                                 = '全局设定';
$LNG['lm_module']                                    = '模块启用状态';
$LNG['lm_cronjob']                                   = '任务调度程序';
$LNG['lm_dump']                                      = '数据库备份';
$LNG['lm_universe']                                  = '各宇宙服状态';
$LNG['lm_rights']                                    = '设置管理员';
$LNG['lm_reset']                                     = '恢复出厂设定';
$LNG['lm_create']                                    = '创造数据';
$LNG['lm_accounteditor']                             = '覆写编辑';
$LNG['lm_ban']                                       = '小黑屋';
$LNG['lm_giveaway']                                  = '全服补偿';
$LNG['lm_support']                                   = '技术支持';
$LNG['lm_active']                                    = '激活用户';
$LNG['lm_flyingfleet']                               = '飞行中的舰队';
$LNG['lm_news']                                      = '公告';
$LNG['lm_messagelist']                               = '已发送信息';
$LNG['lm_search']                                    = '搜索编辑';
$LNG['lm_multiip']                                   = '多IP用户';
$LNG['lm_sendmessages']                              = '游戏广播';
$LNG['lm_log']                                       = '系统日志';
$LNG['lm_password']                                  = '密码生成器';
$LNG['lm_clearcache']                                = '清空缓存';
$LNG['lm_statupdate']                                = '更新统计';
$LNG['lm_logout']                                    = '退出';
//{IDs_0009} Home
$LNG['ov_header_hello']                              = '欢迎!';
$LNG['ov_text_hello']                                = '当你打开这个后台，我希望你能明白一些事情，这些事情包括对个人隐私的审慎和人权的最基本尊重。:)';
$LNG['ov_text_donat']                                = '本服务器的唯一指定群 %s.';
$LNG['ov_header_statistics']                         = '统计数据';
$LNG['ov_statistics_backups']                        = '数据库备份';
$LNG['ov_statistics_user']                           = '总玩家数量';
$LNG['ov_statistics_userinactive']                   = '不活跃的玩家数量';
$LNG['ov_statistics_useronline']                     = '玩家在线';
$LNG['ov_statistics_planet']                         = '星球总数';
$LNG['ov_statistics_supportticks']                   = '开放的票';
$LNG['ov_statistics_log']                            = '日志的数量';
$LNG['ov_statistics_cron']                           = '活跃日志';
$LNG['ov_statistics_news']                           = '公告的数量';
$LNG['ov_header_credits']                            = '名人堂';
$LNG['ov_credits_name']                              = '名字';
$LNG['ov_credits_rights']                            = '位置';
$LNG['ov_credits_thank_you']                         = '感谢!';
$LNG['ov_credits_thank_you_very_much']               = '非常感谢!';
$LNG['ov_rights_founder_developer']                  = '创始人,开发人员';
$LNG['ov_rights_artist_designer']                    = '艺术家、设计师';
$LNG['ov_rights_interpreter']                        = '翻译者';
$LNG['ov_rights_supervisor']                         = '领导';
$LNG['ov_rights_admin']                              = '管理员';
$LNG['ov_rights_moder']                              = '主持人';
$LNG['ov_rights_host']                               = '主持人';
$LNG['ov_rights_test']                               = '测试者';
$LNG['ov_rights_prog']                               = '程序员';
$LNG['ov_rights_opt']                                = '优化器';
//{IDs_0010} Information
$LNG['in_text_server']                               = '服务器信息:';
$LNG['in_text_version_php']                          = 'PHP 版本:';
$LNG['in_text_json']                                 = 'JSON 可用状态:';
$LNG['in_text_bcmath']                               = 'BCMath 可用状态:';
$LNG['in_text_curl']                                 = 'cURL 可用状态:';
$LNG['in_text_safemode']                             = '安全模式(SafeMode)可用状态:';
$LNG['in_text_memorylimit']                          = '内存限制:';
$LNG['in_text_mysql_client']                         = 'MySQL 客户端版本:';
$LNG['in_text_mysql']                                = 'MySQL 版本:';
$LNG['in_text_error_log']                            = '错误日志:';
$LNG['in_text_timezone']                             = '时区 (PHP/CONF/USER):';
$LNG['in_text_suhosin']                              = 'Suhosin 可用/不可用:';
$LNG['in_text_game_version']                         = '游戏版本:';
$LNG['in_text_bd_version']                           = 'Database 版本:';
$LNG['in_text_game_adresse']                         = '游戏地址:';
$LNG['in_text_game_pfad']                            = '游戏路径:';
//{IDs_0010} Parameters
//{IDs_0011} Parameters of the universe
$LNG['cu_class_server']                              = '宇宙的参数';
$LNG['cu_game_name']                                 = '游戏名字';
$LNG['cu_ttf_file']                                  = 'TTF字体文件的路径';
$LNG['cu_timezone']                                  = '时区';
//{IDs_0012} Accounts
$LNG['cu_class_user']                                = '用户';
$LNG['cu_del_oldstuff']                              = '删除信息';
$LNG['cu_del_user_manually']                         = '删除账号';
$LNG['cu_del_user_automatic']                        = '删除不活跃玩家';
$LNG['cu_sendmail_inactive']                         = '使发送提醒';
$LNG['cu_del_user_sendmail']                         = '发送提醒';
//{IDs_0013} Security code
$LNG['cu_class_recapthca']                           = '安全码';
$LNG['cu_capaktiv']                                  = '启用';
$LNG['cu_cappublic']                                 = '公钥';
$LNG['cu_capprivate']                                = '私钥';
//{IDs_0014} Mail
$LNG['cu_class_smtp']                                = '邮件';
$LNG['cu_mail_active']                               = '可用的';
$LNG['cu_mail_use']                                  = '邮寄方式';
$LNG['cu_smtp_sendmail']                             = '英文地址';
$LNG['cu_smail_path']                                = '邮件地址 / Qmail';
$LNG['cu_smtp_host']                                 = 'SMTP Host';
$LNG['cu_smtp_ssl']                                  = 'SMTP Encryption（加密）';
$LNG['cu_smtp_port']                                 = 'SMTP Port';
$LNG['cu_smtp_user']                                 = 'SMTP Login';
$LNG['cu_smtp_pass']                                 = 'SMTP Password';
//{IDs_0015} Messages
$LNG['cu_class_messages']                            = '信息';
$LNG['cu_message_delete_behavior']                   = '可用';
$LNG['cu_message_delete_days']                       = '删除消息通过:';
//{IDs_0016} Visit statistics
$LNG['cu_class_analytics']                           = '统计数据的访问';
$LNG['cu_ga_active']                                 = '可用';
$LNG['cu_ga_key']                                    = '钥匙';
//{IDs_0017} Chat
$LNG['cu_class_chat']                                = '聊天';
$LNG['cu_chat_channelname']                          = '默认的频道名称';
$LNG['cu_chat_botname']                              = '机器人名字';
$LNG['cu_chat_nickchange']                           = '允许昵称变化';
$LNG['cu_chat_logmessage']                           = '显示关于进入和离开聊天的消息';
$LNG['cu_chat_allowmes']                             = '允许私人信息';
$LNG['cu_chat_allowchan']                            = '允许私人频道';
$LNG['cu_chat_closed']                               = '关闭聊天';
//{IDs_0018} Teamspeak
$LNG['cu_class_teamspeak']                           = 'Teamspeak';
$LNG['cu_ts_modon']                                  = '允许 Teamspeak';
$LNG['cu_ts_version']                                = 'Teamspeak 版本';
$LNG['cu_ts_server']                                 = '服务器 IP';
$LNG['cu_ts_tcpport']                                = 'UDP port';
$LNG['cu_ts_udpport']                                = 'TCP port';
$LNG['cu_ts_login']                                  = '登录';
$LNG['cu_ts_password']                               = '密码';
$LNG['cu_ts_timeout']                                = '延迟';
$LNG['cu_ts_cron_interval']                          = '更新的速度';
//{IDs_0019} Main parameters
$LNG['cu_class_universe']                            = '基本参数';
$LNG['cu_uni_name']                                  = '宇宙的名字';
$LNG['cu_lang']                                      = '语言';
$LNG['cu_game_speed']                                = '游戏速度';
$LNG['cu_fleet_speed']                               = '舰队速度';
$LNG['cu_resource_multiplier']                       = 'Type 1 资源生产速度';
$LNG['cu_storage_multiplier']                        = 'type 1 资源存储容量';
$LNG['cu_halt_speed']                                = '探险速度';
$LNG['cu_energySpeed']                               = 'Type 2 资源生产速度';
$LNG['cu_forum_url']                                 = '论坛地址';
$LNG['cu_game_disable']                              = '打开游戏';
$LNG['cu_close_reason']                              = '分离的原因';
//{IDs_0020} Queue
$LNG['cu_class_queqe']                               = '队列';
$LNG['cu_max_elements_build']                        = '建筑队列';
$LNG['cu_max_elements_tech']                         = '研究队列';
$LNG['cu_max_elements_ships']                        = '船厂队列中的插槽';
$LNG['cu_max_fleet_per_build']                       = '船厂队列里的单位';
//{IDs_0021} Referral system
$LNG['cu_class_referral']                            = '推荐系统';
$LNG['cu_ref_active']                                = '启用';
$LNG['cu_ref_bonus']                                 = '奖励';
$LNG['cu_ref_minpoints']                             = '推荐点';
$LNG['cu_ref_max_referals']                          = '推荐';
//{IDs_0022} Colonization
$LNG['cu_class_colonization']                        = '殖民';
$LNG['cu_min_player_planets']                        = 'Max. 行星没有天体物理学';
$LNG['cu_planets_tech']                              = 'Max. 行星的天体物理学';
$LNG['cu_planets_officier']                          = 'Max. 皇帝的行星 ';
$LNG['cu_planets_per_tech']                          = '天体物理学的每个层次的行星';
//{IDs_0023} New planets
$LNG['cu_class_start']                               = '新的行星';
$LNG['cu_metal_start']                               = '金属';
$LNG['cu_crystal_start']                             = '水晶';
$LNG['cu_deuterium_start']                           = '重氢';
$LNG['cu_darkmatter_start']                          = '暗物质';
$LNG['cu_initial_fields']                            = '字段';
$LNG['cu_metal_basic_income']                        = '金属生产';
$LNG['cu_crystal_basic_income']                      = '水晶生产';
$LNG['cu_deuterium_basic_income']                    = '重氢生产';
//{IDs_0024} Miscellaneous
$LNG ['cu_class_other']                              = '杂项';
$LNG['cu_min_build_time']                            = '施工时间';
$LNG['cu_reg_closed']                                = '禁用注册';
$LNG['cu_user_valid']                                = '启用账户激活';
$LNG['cu_adm_attack']                                = '管理员保护';
$LNG['cu_debug']                                     = '启用调试模式';
$LNG['cu_Fleet_Cdr']                                 = '残骸中的舰队';
$LNG['cu_Defs_Cdr']                                  = '残骸中的防御';
$LNG['cu_max_galaxy']                                = '星系';
$LNG['cu_max_system']                                = '系统';
$LNG['cu_max_planets']                               = '行星';
$LNG['cu_planet_factor']                             = '行星大小的因素';
$LNG['cu_max_overflow']                              = '存储的因素';
$LNG['cu_moon_factor']                               = '月球的形成因素';
$LNG['cu_moon_chance']                               = '月球形成的几率';
$LNG['cu_deuterium_cost_galaxy']                     = '穿越星系';
$LNG['cu_cost_trader']                               = '买方费用';
$LNG['cu_factor_university']                         = '技术社会因素';
$LNG['cu_max_fleets_per_acs']                        = '舰队在SAB';
$LNG['cu_silo_factor']                               = '火箭我的因素';
$LNG['cu_vmode_min_time']                            = '假期模式';
$LNG['cu_gate_wait_time']                            = '传送重新加载';
$LNG['cu_debris_moon']                               = '清理残骸场';
$LNG['cu_noobprotection']                            = '开启新手保护';
$LNG['cu_noobprotectiontime']                        = '上保护条';
$LNG['cu_noobprotectionmulti']                       = '下保护条';
$LNG['cu_max_dm_missions']                           = '同时进行TM搜索作业的限制';
$LNG['cu_alliance_create_min_points']                = '组成联盟的要点';
//{IDs_0025} Fleet Buyer
$LNG['cu_class_merchant']                            = '舰队的买家';
$LNG['cu_trade_allowed_ships']                       = '船只';
$LNG['cu_trade_charge']                              = '买方佣金';
//{IDs_0026} News
$LNG['cu_class_news']                                = 'News';
$LNG['cu_OverviewNewsFrame']                         = '启用';
$LNG['cu_OverviewNewsText']                          = '内容';
//{IDs_0027} Statistics
$LNG['cu_class_stat']                                = '统计数据';
$LNG['cu_stat_settings']                             = '1个统计点的成本(资源)';
$LNG['cu_stat']                                      = '0分更新玩家';
$LNG['cu_stat_level']                                = '访问级别';
//{IDs_0028} Facebook
$LNG['cu_class_facebook']                            = 'Facebook';
$LNG['cu_fb_on']                                     = '启用 Facebook';
$LNG['cu_fb_apikey']                                 = 'API ID';
$LNG['cu_fb_skey']                                   = '私钥';
//{IDs_0029} Contacts
$LNG['cu_class_contacts']                            = '联系人';
$LNG['cu_disclamerAddress']                          = '地址';
$LNG['cu_disclamerPhone']                            = 'Phone';
$LNG['cu_disclamerMail']                             = 'Email';
$LNG['cu_disclamerNotice']                           = '额外的信息';
//{IDs_0030} Modules
$LNG['mod_id']                                       = '№';
$LNG['mod_name']                                     = '名字';
$LNG['mod_status']                                   = '状态';
$LNG['mod_value']                                    = '行动';
$LNG['mod_0']                                        = '联盟';
$LNG['mod_1']                                        = '使命——攻击';
$LNG['mod_2']                                        = '构建';
$LNG['mod_3']                                        = '研究';
$LNG['mod_4']                                        = '舰队';
$LNG['mod_5']                                        = '国防';
$LNG['mod_6']                                        = '朋友';
$LNG['mod_7']                                        = '聊天';
$LNG['mod_8']                                        = '创新发展';
$LNG['mod_9']                                        = '舰队';
$LNG['mod_10']                                       = '舰队处理程序';
$LNG['mod_11']                                       = '星系';
$LNG['mod_12']                                       = '名人堂';
$LNG['mod_13']                                       = '交易者';
$LNG['mod_14']                                       = '信息';
$LNG['mod_15']                                       = '帝国';
$LNG['mod_16']                                       = '信息';
$LNG['mod_17']                                       = '注释';
$LNG['mod_18']                                       = '军官';
$LNG['mod_19']                                       = '方阵';
$LNG['mod_20']                                       = 'Player';
$LNG['mod_21']                                       = 'Blocked';
$LNG['mod_22']                                       = '记录';
$LNG['mod_23']                                       = '资源';
$LNG['mod_25']                                       = '统计学';
$LNG['mod_24']                                       = '使命——间谍';
$LNG['mod_26']                                       = '搜索';
$LNG['mod_27']                                       = '技术支持';
$LNG['mod_28']                                       = '技术';
$LNG['mod_29']                                       = '使命——摧毁';
$LNG['mod_30']                                       = '使命——探险';
$LNG['mod_31']                                       = '任务-寻找暗物质';
$LNG['mod_32']                                       = '使命——回收';
$LNG['mod_33']                                       = '使命-坚持';
$LNG['mod_34']                                       = '使命——运输';
$LNG['mod_35']                                       = '使命——殖民';
$LNG['mod_36']                                       = '使命——部署';
$LNG['mod_37']                                       = '旗帜';
$LNG['mod_38']                                       = '舰队的买家';
$LNG['mod_39']                                       = '战斗模拟器';
$LNG['mod_40']                                       = '导弹攻击';
$LNG['mod_41']                                       = '路途';
$LNG['mod_42']                                       = '使命 - ACS';
$LNG['mod_43']                                       = '市场';
$LNG['mod_44']                                       = '竞赛';
$LNG['mod_45']                                       = '奖金';
$LNG['mod_46']                                       = '额外的按钮';
$LNG['mod_47']                                       = '帝国的奖金';
$LNG['mod_48']                                       = '创建月球';
$LNG['mod_49']                                       = '兵工厂';
$LNG['mod_50']                                       = '容器';
$LNG['mod_51']                                       = '史前古器物';
$LNG['mod_52']                                       = '创新发展';
$LNG['mod_53']                                       = '业绩';
$LNG['mod_54']                                       = '政体';
$LNG['mod_55']                                       = '伦理学';
$LNG['mod_56']                                       = '意识形态';
$LNG['mod_57']                                       = '当事人';
$LNG['mod_58']                                       = '古人的容器';
$LNG['mod_59']                                       = '佣兵密令';
$LNG['mod_60']                                       = '公平的';
$LNG['mod_61']                                       = '拍卖';
$LNG['mod_62']                                       = '购买建筑';
$LNG['mod_63']                                       = '购买的研究';
$LNG['mod_64']                                       = '买舰队';
$LNG['mod_65']                                       = '买防御';
$LNG['mod_66']                                       = '天文馆';
$LNG['mod_67']                                       = '从行星上移除舰队';
$LNG['mod_68']                                       = '从行星上移除资源';
$LNG['mod_69']                                       = '分配星球上的资源';
$LNG['mod_70']                                       = '发现残骸';
$LNG['mod_71']                                       = '商店';
$LNG['mod_72']                                       = '任务-到星云区探险';
$LNG['mod_73']                                       = '矿物';
$LNG['mod_74']                                       = '细节';
//{IDs_0031} Task Scheduler
$LNG['cron_name_referral']                           = '推荐系统';
$LNG['cron_name_statistic']                          = '统计数据';
$LNG['cron_name_daily']                              = '日常任务';
$LNG['cron_name_cleaner']                            = '删除旧文件';
$LNG['cron_name_inactive']                           = '删除不活动的玩家';
$LNG['cron_name_teamspeak']                          = '为了更新数据';
$LNG['cron_name_tracking']                           = '向全局服务器发送统计信息';
$LNG['cron_name_databasedump']                       = '备份数据库';
$LNG['cron_id']                                      = 'ID';
$LNG['cron_name']                                    = '任务';
$LNG['cron_min']                                     = '分钟';
$LNG['cron_hours']                                   = '小时';
$LNG['cron_dom']                                     = '天';
$LNG['cron_month']                                   = '月';
$LNG['cron_dow']                                     = '天';
$LNG['cron_class']                                   = '等级';
$LNG['cron_next_time']                               = '发射';
$LNG['cron_in_active']                               = '启用';
$LNG['cron_lock']                                    = 'Blocked';
$LNG['cron_edit']                                    = '编辑';
$LNG['cron_delete']                                  = '删除';
$LNG['cron_new']                                     = '创建一个新任务';
$LNG['cron_error_name']                              = '您没有输入名称。';
$LNG['cron_error_min']                               = '你还没有输入一分钟。';
$LNG['cron_error_hours']                             = '你还没有输入一小时。';
$LNG['cron_error_month']                             = '你还没有输入一个月。';
$LNG['cron_error_dow']                               = '您没有输入工作日。';
$LNG['cron_error_dom']                               = '您没有输入天数。';
$LNG['cron_error_class']                             = '您没有指定一个类。';
$LNG['cron_error_filenotfound']                      = '文件未找到:';
$LNG['cron_headline']                                = '任务 ID';
$LNG['cron_new']                                     = '创建一个新任务';
$LNG['cron_selectall']                               = '全部';
//{IDs_0032} Database backup
$LNG['du_submit']                                    = '备份';
$LNG['du_select_all_tables']		                 = '所有的表';
$LNG['du_choose_tables']			                 = '选择表';
$LNG['du_success']					                 = '备份成功创建!文件:%s';
$LNG['du_not_tables_selected']		                 = '您没有选择要备份的表!';
//{IDs_0033} Universes
$LNG['uvs_id']                                       = 'ID';
$LNG['uvs_name']                                     = '名字';
$LNG['uvs_speeds']						             = '速度的因素 (G/F/R/E)';
$LNG['uvs_players']                                  = '玩家';
$LNG['uvs_planets']                                  = '行星和卫星';
$LNG['uvs_inactive']                                 = '不活跃的';
$LNG['uvs_open']                                     = '状态';
$LNG['uvs_actions']                                  = '行动';
$LNG['uvs_on']                                       = '启用';
$LNG['uvs_off']                                      = '不可用';
$LNG['uvs_delete']                                   = '删除';
$LNG['uvs_new']                                      = '创造宇宙';
$LNG['uvs_reload']                                   = '更新';
$LNG['uvs_back']                                     = '返回';
//{IDs_0034} Rights
$LNG['rh_header_rights']                             = '权利';
$LNG['rh_text_rights']                               = '编辑一个新的排名的权利!';
$LNG['rh_header_users']                              = '上传';
$LNG['rh_text_users']                                = '给某人指派一个新职位!';
$LNG['rh_authlevel_auth']                            = '位置';
$LNG['rh_authlevel_succes']                          = '位置改变了';
$LNG['rh_authlevel_error']                           = '你不能改变游戏创造者的位置。';
$LNG['rh_authlevel_insert_id']                       = '游戏者 ID (选项):';
$LNG['rh_authlevel_aa']                              = '管理员';
$LNG['rh_authlevel_oo']                              = '操作者';
$LNG['rh_authlevel_mm']                              = '版主';
$LNG['rh_authlevel_jj']                              = '玩家';
$LNG['rh_authlevel_tt']                              = '所有';
//{IDs_0035} Zeroing
$LNG['re_reset_universe_confirmation']               = '注意:该进程在启动后不能被取消。在开始之前确保有一个数据库备份。如果要重置所选项，请单击“确定”。';
$LNG['re_player_and_planets']                        = '玩家，行星和卫星';
$LNG['re_reset_player']                              = '重置玩家';
$LNG['re_reset_planets']                             = '重置行星';
$LNG['re_reset_moons']                               = '零的卫星';
$LNG['re_defenses_and_ships']                        = '舰队和国防';
$LNG['re_defenses']                                  = '重置国防';
$LNG['re_ships']                                     = '重置舰队';
$LNG['re_reset_hangar']                              = '关闭造船厂的舰队和防线';
$LNG['re_buldings']                                  = '建筑';
$LNG['re_buildings_pl']                              = '重置行星结构';
$LNG['re_buildings_lu']                              = '零月球建筑';
$LNG['re_reset_buldings']                            = '重置建筑队列';
$LNG['re_inve_ofis']                                 = '研究人员';
$LNG['re_ofici']                                     = '重置军官';
$LNG['re_investigations']                            = '重置的研究';
$LNG['re_reset_invest']                              = '重置研究队列';
$LNG['re_resources']                                 = '资源';
$LNG['re_resources_dark']                            = '零暗物质';
$LNG['re_resources_met_cry']                         = '没有金属，晶体，氘';
$LNG['re_general']                                   = '一般';
$LNG['re_reset_notes']                               = '重置笔记';
$LNG['re_reset_rw']                                  = '重置战斗报告';
$LNG['re_reset_buddies']                             = '重置好友列表';
$LNG['re_reset_allys']                               = '重置联盟';
$LNG['re_reset_fleets']                              = '重置舰队';
$LNG['re_reset_errors']                              = '重置错误列表';
$LNG['re_reset_banned']                              = '重置被阻止的列表';
$LNG['re_reset_messages']                            = '重置信息';
$LNG['re_reset_statpoints']                          = '重置统计信息';
$LNG['re_reset_all']                                 = '整个宇宙归零';
$LNG['re_reset_excess']                              = '有标记的项目被重置.';
//{IDs_0036} Create
$LNG['cr_header_user']                               = 'Player';
$LNG['cr_text_user']                                 = '创建一个新的player!';
$LNG['cr_header_planet']                             = '行星';
$LNG['cr_text_planet']                               = '创建一个新的行星!';
$LNG['cr_header_moon']                               = '月亮';
$LNG['cr_text_moon']                                 = '创建一个新的月亮!';
//{IDs_0037} Creating a player
$LNG['cr_new_user_success']                          = '玩家已被创建.';
$LNG['cr_new_range']                                 = '位置';
$LNG['cr_new_coord']                                 = '坐标';
$LNG['cr_new_email_1']                               = 'Email';
$LNG['cr_new_email_2']                               = 'Email (确认)';
$LNG['cr_new_pass_1']                                = '密码';
$LNG['cr_new_pass_2']                                = '密码 (确认)';
$LNG['cr_new_name']                                  = '登录';
$LNG['cr_new_lang']                                  = '语言';
$LNG['cr_invalid_mail_adress']                       = 'email已经存在!';
$LNG['cr_empty_user_field']                          = '登录未指定!';
$LNG['cr_password_lenght_error']                     = '密码太短!';
$LNG['cr_different_passwords']                       = '密码不匹配!';
$LNG['cr_different_mails']                           = '邮件不匹配!';
$LNG['cr_user_field_specialchar']                    = '登录中有特殊字符!';
$LNG['cr_user_already_exists']                       = '此登录名已经存在!';
$LNG['cr_mail_already_exists']                       = '此邮件已经存在!';
$LNG['cr_planet_already_exists']                     = '主行星的位置被占据了!';
//{IDs_0038} Creating a planet
$LNG['cr_name_planet']                               = '名字';
$LNG['cr_fields_max']                                = '字段';
$LNG['cr_complete_all2']                             = '输入了不存在的坐标。';
$LNG['cr_complete_all']                              = '指定的坐标已经被获取。';
$LNG['cr_complete_succes']                           = '行星被创造了。';
//{IDs_0039} Creating the moon
$LNG['cr_moon_name']                                 = '名字';
$LNG['cr_mo_moon']                                   = '月亮';
$LNG['cr_diameter']                                  = '直径';
$LNG['cr_moon_random']                               = '随机';
$LNG['cr_planet_doesnt_exist']                       = '该星球并不存在。';
$LNG['cr_moon_added']                                = '月亮被创造出来了。';
$LNG['cr_moon_unavaible']                            = '被指示的行星已经有一个卫星了。';
//{IDs_0040} Account Editor
$LNG['ac_header_buildings']                          = '建筑';
$LNG['ac_text_buildings']                            = '建造新建筑';
$LNG['ac_header_ships']                              = '舰队';
$LNG['ac_text_ships']                                = '增加一个新的舰队!';
$LNG['ac_header_defenses']                           = '国防';
$LNG['ac_text_defenses']                             = '创建一个新的防御复合体!';
$LNG['ac_header_researchs']                          = '研究';
$LNG['ac_text_researchs']                            = '改变研究水平!';
$LNG['ac_header_officiers']                          = '军官';
$LNG['ac_text_officiers']                            = '提高军官的级别!';
$LNG['ac_header_resources']                          = '资源';
$LNG['ac_text_resources']                            = '添加新资源!';
$LNG['ac_header_planets']                            = '行星';
$LNG['ac_text_planets']                              = '改变这颗行星的特性!';
$LNG['ac_header_alliances']                          = '联盟';
$LNG['ac_text_alliances']                            = '编辑联盟!';
$LNG['ac_header_personal']                           = 'Player';
$LNG['ac_text_personal']                             = '更改玩家的个人数据!';
//{IDs_0041} Planet Editor
$LNG['ac_pla_edit_name']                             = '名字';
$LNG['ac_pla_edit_diameter']                         = '直径';
$LNG['ac_pla_edit_fields']                           = '字段';
$LNG['ac_pla_delete_b']                              = '删除所有的建筑物';
$LNG['ac_pla_delete_s']                              = '删除整个舰队';
$LNG['ac_pla_delete_d']                              = '删除所有防御';
$LNG['ac_pla_delete_hd']                             = '清空造船厂和防御队伍';
$LNG['ac_pla_delete_cb']                             = '删除建筑物的队列';
$LNG['ac_pla_change_pp']                             = '选中复选框以更改坐标';
$LNG['ac_pla_error_planets3']                        = '坐标已经有人了。';
$LNG['ac_pla_error_planets4']                        = '月球已经存在了。';
$LNG['ac_pla_error_planets5']                        = '在这些坐标上已经有一颗行星了。';
$LNG['ac_pla_succes']                                = '修改保存';
//{IDs_0042} Alliance Editor
$LNG['ac_ally_change_id']                            = '章';
$LNG['ac_ally_name']                                 = '名字';
$LNG['ac_ally_tag']                                  = '缩写';
$LNG['ac_ally_text1']                                = '外部文本';
$LNG['ac_ally_text2']                                = '内部文本';
$LNG['ac_ally_text3']                                = '请求的文本';
$LNG['ac_ally_delete']                               = '删除联盟';
$LNG['ac_ally_delete_u']                             = '删除的玩家 (玩家 ID)';
$LNG['ad_ally_succes']                               = '联盟信息已更改。';
//{IDs_0043} Personal data editor
$LNG['ac_personal_name']                             = '登录';
$LNG['ac_personal_email']                            = 'Email';
$LNG['ac_personal_email2']                           = '永久 Email';
$LNG['ac_personal_pass']                             = '密码';
$LNG['ac_personal_vacat']                            = '假日模式';
$LNG['ac_personal_succes']                           = '个人资料修改.';
//{IDs_0044} Other editor
$LNG['ac_add_sucess']                                = '对象添加.';
$LNG['ac_delete_sucess']                             = '对象删除.';
$LNG['ac_add_not_exist']                             = '指定的ID不存在';
$LNG['ac_register_time']                             = '登记';
$LNG['ac_act_time']                                  = '活动';
//{IDs_0045} Lock Panel
$LNG['bo_the_player']                                = 'Player';
$LNG['bo_the_player2']                               = 'Player';
$LNG['bo_banned']                                    = 'blocked.';
$LNG['bo_unbanned']                                  = 'unlocked.';
$LNG['bo_username']                                  = 'Player';
$LNG['bo_vacaations']                                = '假期模式';
$LNG['bo_reason']                                    = 'blocking的原因';
$LNG['bo_time']                                      = '锁定时间';
$LNG['bo_vacation_mode']                             = '启用度假模式';
$LNG['bo_ban_player']                                = 'Player 列表';
$LNG['bo_unban_player']                              = 'blocked players的列表';
$LNG['bo_permanent']                                 = '永久的锁';
$LNG['bo_bbb_title_1']                               = '锁面板';
$LNG['bo_bbb_title_2']                               = 'blocking的持续时间';
$LNG['bo_bbb_title_3']                               = '停职系统 <font color="red">这个玩家被锁定了</font>';
$LNG['bo_bbb_title_4']                               = '要缩短阻塞时间，可以加一个带减号的数字，例如-5。';
$LNG['bo_bbb_title_5']                               = 'Blocked until';
$LNG['bo_bbb_title_6']                               = '阻断时间';
$LNG['bo_characters_1']                              = '可用的字符';
$LNG['bo_characters_suus']                           = '(blocked)';
$LNG['bo_order_username']                            = '按名称排序';
$LNG['bo_order_id']                                  = '按ID排序';
$LNG['bo_order_banned']                              = '按日期排序';
$LNG['bo_total_users']                               = '总玩家数:';
$LNG['bo_total_banneds']                             = 'Blocked 的玩家:';
$LNG['bo_ban']                                       = 'Block';
$LNG['bo_unban']                                     = 'Unblock';
//{IDs_0046} Gifts
$LNG['gi_success']                                   = '礼物.';
$LNG['gi_selectplanettype']                          = '请至少选择一种类型.';
$LNG['gi_homecoordinates']                           = '只在主星球上';
$LNG['gi_no_inactives']                              = '排除不活跃的球员';
//{IDs_0047} Tech. support
$LNG['sp_answer_message_title']                      = '支持的工单%s';
$LNG['sp_answer_message']                            = '你的支持工单上有新的回复: <a href=?page=ticket> %s</a>!';
//{IDs_0048} Activation page
$LNG['ap_username']						             = '用户名';
$LNG['ap_datum']					            	 = '日期';
$LNG['ap_email']						             = 'Email';
$LNG['ap_ip']							             = 'IP';
$LNG['ap_aktivieren']					             = '激活';
$LNG['ap_status']						             = '状态';
$LNG['ap_del']							             = '删除';
$LNG['ap_sicher']						             = '你能肯定';
$LNG['ap_entfernen']					             = '想要删除';
$LNG['ap_insgesamt']					             = '一般';
$LNG['ap_nicht_aktivierte']				             = '没有被用户激活';
//{IDs_0049} Fleets in flight
$LNG['ff_mission']				                     = "任务";
$LNG['ff_starttime']			                     = "开始";
$LNG['ff_ships']			            	         = "船只";
$LNG['ff_startuser']			                     = "发射机";
$LNG['ff_startplanet']			                     = "行星发射机";
$LNG['ff_arrivaltime']			                     = "开始时间";
$LNG['ff_targetuser']			                     = "收件人";
$LNG['ff_targetplanet']			                     = "行星上收件人";
$LNG['ff_endtime']				                     = "结束时间";
$LNG['ff_holdtime']				                     = "时间停止了";
$LNG['ff_del']					                     = "删除";
$LNG['ff_lock']					                     = "Block";
$LNG['ff_unlock']				                     = "Unlock";
$LNG['ff_no_fleets']			                     = "没有舰队吗";
//{IDs_0050} News
$LNG['nws_head_create']                              = '创建公告';
$LNG['nws_head_edit']                                = '正在做公告';
$LNG['nws_id']                                       = 'ID';
$LNG['nws_title']                                    = '标题';
$LNG['nws_date']                                     = '日期';
$LNG['nws_from']                                     = '作者';
$LNG['nws_del']                                      = '删除';
$LNG['nws_confirm']                                  = '您确定要删除消息的%s吗?';
$LNG['nws_create']                                   = '创建消息';
$LNG['nws_content']                                  = '内容';
//{IDs_0051} List of messages
$LNG['ml_sender']                                    = '发射机';
$LNG['ml_receiver']                                  = '收件人';
$LNG['ml_date']                                      = '日期';
$LNG['ml_type']                                      = '类型';
$LNG['ml_date_range']                                = '时间';
$LNG['ml_page']                                      = '页面';
$LNG['ml_subject']                                   = '主题';
//{IDs_0052} Advanced Search
$LNG['se_no_data']                                   = "没有数据.";
$LNG['se_intro']                                     = '字或符号(可选)';
$LNG['se_users']                                     = 'Players';
$LNG['se_planets']                                   = 'Planets';
$LNG['se_moons']                                     = '月亮';
$LNG['se_allys']                                     = '联盟';
$LNG['se_suspended']                                 = 'Blocked';
$LNG['se_vacations']                                 = '假期模式';
$LNG['se_authlevels']                                = '管理员';
$LNG['se_inactives']                                 = '不活跃的';
$LNG['se_planets_act']                               = '活跃的行星';
$LNG['se_type_typee']                                = '类型';
$LNG['se_type_all']                                  = '基本的搜索';
$LNG['se_type_exact']                                = '精确的搜索';
$LNG['se_type_last']                                 = '以任何单词或字母开头';
$LNG['se_type_first']                                = '以任何单词或字母结尾';
$LNG['se_search']                                    = '搜索';
$LNG['se_name']                                      = '登录';
$LNG['se_id_owner']                                  = 'ID';
$LNG['se_galaxy']                                    = '星系';
$LNG['se_system']                                    = '系统';
$LNG['se_planet']                                    = '行星';
$LNG['se_tag']                                       = '缩写';
$LNG['se_email']                                     = 'Email';
$LNG['se_auth']                                      = '位置';
$LNG['se_activity']                                  = '上次访问';
$LNG['se_ban']                                       = 'Ban';
$LNG['se_vacat']                                     = 'PO';
$LNG['se_ban_reason']                                = '原因';
$LNG['se_ban_time']                                  = 'When';
$LNG['se_ban_limit']                                 = 'Blocked until';
$LNG['se_ban_author']                                = 'Who blocked';
$LNG['se_search_title']                              = '高级搜索';
$LNG['se_order_list_now']                            = '搜索';
$LNG['se_input_name']                                = '登录';
$LNG['se_input_g']                                   = '星系';
$LNG['se_input_s']                                   = '系统';
$LNG['se_input_p']                                   = '行星';
$LNG['se_input_inacti']                              = '不活跃的';
$LNG['se_input_submit']                              = '行动';
$LNG['se_input_authlevel']                           = '位置';
$LNG['se_input_email']                               = 'Email';
$LNG['se_input_time']                                = 'When Blocked';
$LNG['se_input_longer']                              = 'Blocked until';
$LNG['se_input_authlevel']                           = '权限';
$LNG['se_input_prop']                                = 'Owner';
$LNG['se_input_asc']                                 = '提升';
$LNG['se_input_desc']                                = '下行';
$LNG['se_input_activity']                            = '活动';
$LNG['se_input_register']                            = '登记';
$LNG['se_input_members']                             = '任何成员';
$LNG['se_input_members2']                            = '成员';
$LNG['se_input_have_moon']                           = '有一个月亮';
$LNG['se_input_ip']                                  = 'IP';
$LNG['se_input_a']                                   = 'B';
$LNG['se_input_d']                                   = 'Y';
$LNG['se_input_hay']                                 = '';
$LNG['se_input_inact']                               = '不活跃的发现';
$LNG['se_input_susss']                               = 'blocked found';
$LNG['se_input_admm']                                = 'Administrators found';
$LNG['se_input_allyy']                               = 'alliances found';
$LNG['se_input_planett']                             = 'planets found';
$LNG['se_input_moonn']                               = 'moons found';
$LNG['se_input_userss']                              = 'players found';
$LNG['se_input_vacatii']                             = 'RO players found';
$LNG['se_input_connect']                             = 'online players';
$LNG['se_input_act_pla']                             = '活跃的行星';
$LNG['se_filter_title']                              = '过滤器';
$LNG['se_search_in']                                 = 'For';
$LNG['online_users']                                 = '在线';
$LNG['se_limit']                                     = '限制';
$LNG['se_pagees']                                    = '页面';
$LNG['se_time_of_page']                              = '页面中创建';
$LNG['se_expand']                                    = '增加';
$LNG['se_contrac']                                   = '展示/隐藏';
$LNG['se__next']                                     = '下一个';
$LNG['se__before']                                   = '返回';
$LNG['se_search_info']                               = '编辑';
$LNG['se_asc_desc']                                  = '排序';
$LNG['se_search_order']                              = '行动';
$LNG['se_search_edit']                               = '编辑';
$LNG['se_delete_succes_p']                           = '已删除';
$LNG['se_confirm_planet']                            = '所有被选中的行星会被完全删除吗?行星名称: ';
//{Is_0053} Advanced Search - Players
$LNG['se_search_users_0']                            = 'ID';
$LNG['se_search_users_1']                            = '名字';
$LNG['se_search_users_2']                            = 'E-mail';
$LNG['se_search_users_3']                            = '最后一个活动';
$LNG['se_search_users_4']                            = '注册日期';
$LNG['se_search_users_5']                            = '最终IP';
$LNG['se_search_users_6']                            = '权威';
$LNG['se_search_users_7']                            = '暂停?';
$LNG['se_search_users_8']                            = 'PO?';
//{IDs_0054} Advanced Search - Planets
$LNG['se_search_planets_0']                          = 'ID';
$LNG['se_search_planets_1']                          = '名字';
$LNG['se_search_planets_2']                          = "Owner";
$LNG['se_search_planets_3']                          = "最后活动";
$LNG['se_search_planets_4']                          = "Galaxy";
$LNG['se_search_planets_5']                          = "System";
$LNG['se_search_planets_6']                          = "Planet";
$LNG['se_search_planets_7']                          = "Has The Moon?";
//{IDs_0055} Advanced search - blocked
$LNG['se_search_banned_0']                           = 'ID';
$LNG['se_search_banned_1']                           = 'Name';
$LNG['se_search_banned_2']                           = "悬架日期";
$LNG['se_search_banned_3']                           = "重新激活的日期";
$LNG['se_search_banned_4']                           = "原因";
$LNG['se_search_banned_5']                           = "作者";
//{IDs_0056} Advanced Search - Alliance
$LNG['se_search_alliance_0']                         = 'ID';
$LNG['se_search_alliance_1']                         = 'Name';
$LNG['se_search_alliance_2']                         = "TAG";
$LNG['se_search_alliance_3']                         = "管理员";
$LNG['se_search_alliance_4']                         = "创建日期";
$LNG['se_search_alliance_5']                         = "成员数目";
//{IDs_0057} Fast editor
$LNG['qe_username']                                  = 'Login';
$LNG['qe_planetname']                                = 'Name';
$LNG['qe_edit_planet_sucess']			             = 'Planet %s [%d:%d:%d] edited with success!';
$LNG['qe_edit_player_sucess']			             = 'Player %s (ID: %d) edited with success!';
$LNG['qe_info']                                      = '通用数据';
$LNG['qe_fields']                                    = '字段';
$LNG['qe_password']                                  = '密码';
$LNG['qe_coords']                                    = '坐标';
$LNG['qe_hpcoords']                                  = '主行星的名称[坐标](行星ID)';
$LNG['qe_temp']                                      = '温度';
$LNG['qe_authattack']                                = '使攻击保护';
$LNG['qe_allowmulti']                                = '允许IP匹配';
//{IDs_0058} Multi-Accounts
$LNG['mip_known']                                    = '许可';
//{IDs_0059} Global message
$LNG['ma_message_sended']                            = '全局消息已经发送.';
$LNG['ma_subject_needed']                            = '您必须指定全局消息的主题.';
$LNG['ma_subject']                                   = '主题';
$LNG['ma_characters']                                = '字符';
$LNG['ma_none']                                      = '全球信息';
$LNG['ma_message']                                   = '内容';
$LNG['ma_mode']                                      = '种类';
$LNG['ma_all']                                       = 'All';
$LNG['ma_modes']                                     = array ('Game message', 'Email to all players', 'Game message + Email to all players');
//{IDs_0060} Logs
$LNG['log_text_planet']                              = '行星的日志.';
$LNG['log_text_player']                              = 'Player日志.';
$LNG['log_text_settings']                            = '宇宙设置的日志.';
$LNG['log_text_present']                             = '礼物 Logs.';
$LNG['log_log']                                      = 'Log';
$LNG['log_admin']                                    = 'Administrator';
$LNG['log_time']                                     = 'Date';
$LNG['log_target_user']                              = 'Player';
$LNG['log_target_planet']                            = '[planet] -> Player';
$LNG['log_target_universe']                          = '类别';
$LNG['log_info']                                     = '信息';
$LNG['log_element']                                  = '元素';
$LNG['log_old']                                      = 'Before';
$LNG['log_new']                                      = 'After';
$LNG['log_player']                                   = 'Players';
$LNG['log_planet']                                   = 'Planets';
$LNG['log_settings']                                 = 'Settings';
$LNG['log_present']                                  = 'Gifts';
$LNG['log_no_data']                                  = '这个类别中没有数据.';
$LNG['log_usettings']                                = '宇宙的参数';
$LNG['log_disclamersettings']                        = '联系人';
$LNG['log_universe']                                 = '宇宙';
//{IDs_0061} MD5 encryption
$LNG['et_pass']                                      = '文本';
$LNG['et_result']                                    = '结果';
$LNG['et_encript']                                   = '加密';
//{IDs_0062} Cache
$LNG ['cc_cache_clear']                              = '缓存被清除.';
//{IDs_0063} Updating statistics
$LNG['sb_top_memory']					             = 'Peak memory: %p KB / max. %m KB <br>';
$LNG['sb_final_memory']					             = '内存消耗结束: %e KB / max. %m KB<br>';
$LNG['sb_start_memory']					             = '开始时消耗的内存: %i KB / max. %m KB<br>';
$LNG['sb_stats_update']					             = '统计数据更新: %t segundos<br>';
$LNG['sb_stats_updated']				             = ' 更新日期. <br>Resuming:<br>';
$LNG['sb_sql_counts']			                     = 'SQL Querys: %d';
//{IDs_0064} Logout
$LNG['lo_title']                                     = '您已退出登录。再见!';
$LNG['lo_notify']                                    = '您将<span id="seconds">5</span> 秒内被重定向进入 ';
$LNG['lo_continue']                                  = "如果你不想等，请点击这里";