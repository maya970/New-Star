<?php
// Translated into English by Yaro2709;
// All rights reserved from 2020;
// Company 1367.

//NAVIGATION:
//{IDs_0001} Global
//{IDs_0002} Universe select
//{IDs_0003} Button
//{IDs_0004} Login
//{IDs_0005} Register
//{IDs_0006} Vertify
//{IDs_0007} Lostpassword
//{IDs_0008} Case default
//{IDs_0009} News
//{IDs_0010} Impressum

//{IDs_0001} Global

$LNG['nav_forum']						             = '论坛';
$LNG['nav_index']					                 = '主页';
$LNG['nav_news']					                 = '公告';
$LNG['nav_rules']					                 = '规则';
$LNG['nav_banlist']				                     = '黑屋';
$LNG['nav_battlehall']				                 = '著名战场';
$LNG['nav_disclamer']				                 = '联络';
$LNG['nav_register']				                 = '注册';
$LNG['nav_password']				                 = '忘记密码?';
$LNG['nav_screens']				                     = '插画';
$LNG['back']                                         = '返回';
$LNG['next']                                         = '下一步'; 
$LNG['previous_s']                                   = '';
$LNG['next_s']                                       = '';
$LNG['footer_up']                                    = '返回头部';
$LNG['language']			                         = '语言';
//{IDs_0002} Universe select
$LNG['chose_a_uni']					                 = '选择宇宙';
$LNG['universe']					                 = '宇宙';
$LNG['uni_closed']					                 = ' (关闭)';
//{IDs_0003} Button
$LNG['buttonRegister']				                 = '现在注册!';
$LNG['buttonLostPassword']			                 = '忘记密码?';
//{IDs_0004} Login
$LNG['loginUsername']				                 = '账户';
$LNG['loginPassword']				                 = '密码';
$LNG['loginButton']					                 = '登录';
$LNG['loginInfo']					                 = '登录表示我同意 %s.';
$LNG['loginWelcome']				                 = '欢迎来到 %s';
$LNG['loginServerDesc']				                 = '%s 是一款数百名玩家同时在一起玩的空间策略游戏，为防止任何形式的作弊，注册必须加群私聊管理员。';
$LNG['loginScreens']                                 =
'嘿！千万不要忽视我！否则你会错过这样一个最好的画廊的！';
//{IDs_0005} Register
$LNG['registerUsername']			                 = '用户名';
$LNG['registerUsernameDesc']		                 = '您的用户名必须至少有3个字符长，且不超过25个字符。它可能由数字,字母, _, -, . 和空格组成.';
$LNG['registerPassword']			                 = '密码';
$LNG['registerPasswordDesc']		                 = '您的密码必须至少有6个字符长.';
$LNG['registerPasswordReplay']		                 = '确认密码';
$LNG['registerPasswordReplayDesc']	                 = '请重复您的密码.';
$LNG['registerEmail']				                 = 'E-Mail';
$LNG['registerEmailDesc']			                 = '请确认 E-Mail 地址.';
$LNG['registerEmailReplay']			                 = '确认 E-Mail';
$LNG['registerEmailReplayDesc']		                 = '为了安全，请再一次确认 E-Mail 地址.';
$LNG['registerReferral']			                 = '广告来自:';
$LNG['registerCaptcha']				                 = '安全密码';
$LNG['registerCaptchaDesc']		      	             = '请在空字段中输入下面的字符。没有任何区分大小写的功能';
$LNG['registerRulesDesc']			                 = '我同意 %s';
$LNG['registerErrorUniClosed']		                 = '注册的这个宇宙中是关闭的.!';
$LNG['registerErrorUsernameEmpty']	                 = '您必须输入一个用户名!';
$LNG['registerErrorUsernameChar']	                 = '你的用户名可能包括 数字, 字母, _, -, . 和空格!';
$LNG['registerErrorUsernameExist']  	             = '已有人使用此用户名!';
$LNG['registerErrorPasswordLength']	                 = '密码必须至少有6个字符长!';
$LNG['registerErrorPasswordSame']	                 = '输入的密码不匹配!';
$LNG['registerErrorMailEmpty']		                 = '您必须指定一个电子邮件地址!';
$LNG['registerErrorMailInvalid']	                 = '电子邮件地址无效!';
$LNG['registerErrorMailSame']		                 = '您已经指定了两个不同的电子邮件地址!';
$LNG['registerErrorMailExist']		                 = '该电子邮件地址已被注册!';
$LNG['registerErrorRules']			                 = '你必须接受这些规则!';
$LNG['registerErrorCaptcha']		                 = '安全密码不正确!';
$LNG['registerMailVertifyTitle']	                 = '激活的游戏: %s';
$LNG['registerMailCompleteTitle']	                 = '欢迎来到 %s!';
$LNG['registerSendComplete']		                 = '谢谢你的注册。您必须查看电子邮件（注意垃圾邮件）以获取更多信息.';
$LNG['registerWelcomePMSenderName']	                 = 'Administrator';
$LNG['registerWelcomePMSubject']	                 = '欢迎';
$LNG['registerWelcomePMText']		                 = '欢迎来到 %s! 首先建造一个太阳能发电站，因为原材料的生产需要能源。要构建一个，请在菜单中单击。然后从顶部建造第四栋楼。当你有了能源时，你就可以开始建造矿山了。去菜单上的建筑，建一个金属矿，然后是一个水晶矿。  </br></br>为了能够建造船只，你需要有一个造船厂。要了解解锁该建筑物需要什么，您可以查看左侧菜单中的技术信息。</br>如果你有更多的问题，你可以看入门指南，我们的论坛或打开一张工单。</br></br> 拖更希望你探索宇宙时会很享受!';
//{IDs_0006} Vertify
$LNG['vertifyNoUserFound']			                 = '无效的请求!';
$LNG['vertifyAdminMessage']			                 = '这个用户名 "%s" 无效!';
//{IDs_0007} Lostpassword
$LNG['passwordInfo']				                 = '如果您忘记了密码，则必须指定您在帐户中输入的用户名和电子邮件地址.';
$LNG['passwordUsername']			                 = '用户名';
$LNG['passwordMail']				                 = 'E-Mail';
$LNG['passwordSubmit']				                 = '提交';
$LNG['passwordErrorMailEmpty']		                 = '您已经指定了一个未知的电子邮件地址!';
$LNG['passwordErrorUnknown']		                 = '无法在帐户数据中找到它.';
$LNG['passwordErrorOnePerDay']		                 = '最近已请求使用此用户帐户的新密码。您每24小时只能重置一次密码.';
$LNG['passwordValidMailTitle']		                 = '忘记我在游戏中的密码了: %s';
$LNG['passwordValidMailSend']		                 = '您将很快收到一封包含更多信息的电子邮件.';
$LNG['passwordValidInValid']		                 = '无效的请求!';
$LNG['passwordChangedMailSend']		                 = '您很快就会收到一封带有新密码的电子邮件.';
$LNG['passwordChangedMailTitle']	                 = '游戏上的新密码: %s';
//{IDs_0008} Case default
$LNG['login_error_1']				                 = '错误的用户名/密码!';
$LNG['login_error_2']				                 = '有人已从其他电脑登录到您的帐户，或者您的IP已更改!';
$LNG['login_error_3']			 	                 = '您的登录已过期!';
$LNG['login_error_4']				                 = '外部授权中出现错误，请重试!';
//{IDs_0009} News
$LNG['news_from']					                 = '在 %s 来自 %s';
$LNG['news_does_not_exist']			                 = '没有任何消息!';
//{IDs_0010} Impressum
$LNG['disclamerLabelAddress']		                 = '游戏地址:';
$LNG['disclamerLabelPhone']			                 = '手机号码:';
$LNG['disclamerLabelMail']			                 = '支援 Email:';
$LNG['disclamerLabelNotice']		                 = '更多信息';